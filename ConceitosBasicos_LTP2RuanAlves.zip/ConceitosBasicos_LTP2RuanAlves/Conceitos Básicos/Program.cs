﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
string nome = "Seu nome";
Console.WriteLine("Seja bem vindo(a)" + nome);
string cidade = "Pinheiral";
Console.WriteLine($"Eu gosto de {cidade}");

string sobrenome = "de tal", apelido;

int idade = 16;
Console.WriteLine($"a idade informada foi {idade}");

byte valor = 255;
valor += 1; // valor = valor +1;
Console.WriteLine($"valor:{valor}");

float salario = 5000.20f;